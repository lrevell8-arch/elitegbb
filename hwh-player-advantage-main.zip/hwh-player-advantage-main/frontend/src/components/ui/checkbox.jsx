import * as React from "react"
import * as CheckboxPrimitive from "@radix-ui/react-checkbox"
import { Check } from "lucide-react"

import { cn } from "@/lib/utils"

const Checkbox = React.forwardRef(({ className, ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    className={cn(
      "peer h-5 w-5 shrink-0 rounded-sm border-2 border-white/40 bg-white/5 shadow focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#fb6c1d] disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-[#fb6c1d] data-[state=checked]:border-[#fb6c1d] data-[state=checked]:text-white transition-colors",
      className
    )}
    {...props}>
    <CheckboxPrimitive.Indicator className={cn("flex items-center justify-center text-current")}>
      <Check className="h-4 w-4" />
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
))
Checkbox.displayName = CheckboxPrimitive.Root.displayName

export { Checkbox }
